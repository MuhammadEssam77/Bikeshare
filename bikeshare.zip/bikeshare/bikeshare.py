import time
import pandas as pd
import numpy as np

CITY_DATA = { 'chicago': 'chicago.csv',
              'new york city': 'new_york_city.csv',
              'washington': 'washington.csv' }


def get_filters():
    monthes = ["all", "january", "february", "march", "april", "may", "june"]
    days = ["all", "saturday", "sunday", "monday", "tuesday", "wednesday", "thursday", "friday"]    
    """
    Asks user to specify a city, month, and day to analyze.

    Returns:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    """
    print('Hello! Let\'s explore some US bikeshare data!')
    # get user input for city (chicago, new york city, washington). HINT: Use a while loop to handle invalid inputs
    city = ''
    while city.lower() not in CITY_DATA.keys():
        city = input("Please choose a city (chicago/new york city/washington): ")

    # get user input for month (all, january, february, ... , june)
    month = ''
    while month.lower() not in monthes:
        month = input("Please choose a month by name(or use all):")

    # get user input for day of week (all, monday, tuesday, ... sunday)
    day = ''
    while day.lower() not in days:
        day = input("Please choose a day by name(or use all):")

    print('-'*40)
    return city, month, day



def load_data(city, month, day):
    city = city.lower()
    month = month.lower().capitalize()
    day = day.lower().capitalize()
    """
    Loads data for the specified city and filters by month and day if applicable.

    Args:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    Returns:
        df - Pandas DataFrame containing city data filtered by month and day
    """
    df = pd.read_csv(CITY_DATA[city])
    df['date_obj'] =  pd.to_datetime(df['Start Time'], format='%Y-%m-%d %H:%M:%S')
    if day != 'All':
        df = df[df['date_obj'].dt.day_name()==day]
    if month != 'All':
        df = df[df['date_obj'].dt.month_name()==month]
    return df



def time_stats(df):
    """Displays statistics on the most frequent times of travel."""

    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()

    # display the most common month
    if len(df['date_obj'].dt.month_name().value_counts()) == 1:
        print("Working with only 1 month \n")
    else:
        print("Most Common Month is :")
        print(df['date_obj'].dt.month_name().value_counts().keys()[0])

    # display the most common day of week
    if len(df['date_obj'].dt.day_name().value_counts()) == 1:
        print("Working with only 1 day \n")
    else:    
        print("\n Most Common day is :")
        print(df['date_obj'].dt.day_name().value_counts().keys()[0])


    # display the most common start hour
        print("\n Most common Hour is :")
        print(df['date_obj'].dt.hour.value_counts().keys()[0])

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)



def station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    # display most commonly used start station
    print("Most commonly used start station :")
    print(df["Start Station"].value_counts().keys()[0])

    # display most commonly used end station
    print("\n Most commonly used end station")
    print(df["End Station"].value_counts().keys()[0])
    
    # display most frequent combination of start station and end station trip
    print("\n most frequent combination of start station and end station trip:")
    print(df[["Start Station", "End Station"]].value_counts().keys()[0])

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)



def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""

    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    # display total travel time
    print(f'total travel time is:{df["Trip Duration"].sum()}')

    # display mean travel time
    print(f'mean travel time is:{df["Trip Duration"].mean()}')

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)



def user_stats(df):
    """Displays statistics on bikeshare users."""

    print('\nCalculating User Stats...\n')
    start_time = time.time()

    # Display counts of user types
    print("counts of user types:")
    print(df["User Type"].value_counts())

    # Display counts of gender
    print("counts of gender:")
    print(df["Gender"].value_counts())

    # Display earliest, most recent, and most common year of birth
    print(f"Earliest year of birth:{df['Birth Year'].min()}")
    print(f"Most recent year of birth: {df['Birth Year'].max()}")
    print(f"Most common year of birth: {df['Birth Year'].value_counts().keys()[0]}")

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def main():
    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)

        time_stats(df)
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df)

        restart = input('\nWould you like to restart? Enter yes or no.\n')
        if restart.lower() != 'yes':
            break


if __name__ == "__main__":
	main()
